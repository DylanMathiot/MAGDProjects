function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('#9F6BA0')

fill('#4A2040')
arc(190, 190, 480, 1000, 0, PI + QUARTER_PI, CHORD);

fill('#EC9DED')
quad(3, 331, 386, 210, 269, 163, 30, 76);
  
fill('#F4A698')
triangle(30, 125, 1518, 10, 896, 175);


fill(211.09, 82, 105)
quad(3189, 311, 186, 210, 169, 563, 420, 16);

}