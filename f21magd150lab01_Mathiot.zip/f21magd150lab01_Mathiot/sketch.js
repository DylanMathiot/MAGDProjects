function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);225

rectMode(CORNER)
strokeWeight(0)
  
fill(200)
rect(67, 100, 225, 225);
  
fill(200)
rect(68, 90, 178, 200);

fill(200)
rect(67, 55, 50, 65, 45, 45, 10 ,5);  
  
fill(200)
rect(242, 55, 50, 65, 45, 45, 10, 5)
  
fill(100)  
rect(150, 250, 65, 75, 10);
  
fill(150)  
rect(198, 280, 15, 15, 0);
  
fill(150)
rect(210, 140, 45, 45, 0)
  
fill(120) 
rect(228, 140, 10, 45, 0)
  
fill(150)
rect(111, 140, 45, 45, 0)
  
fill(120)
rect(128, 140, 10, 45, 0)

fill(120)

     
}