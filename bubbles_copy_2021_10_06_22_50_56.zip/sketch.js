function setup() {
  createCanvas(500, 500);
  x=0
  x++
  x--
}




// Move the mouse across the canvas
function draw() {
  background(244, 248, 252);
  ellipse(0, mouseY, 100, mouseY);
}


// Move the mouse across the canvas
function draw() {
  background(244, 248, 252);
  ellipse(mouseX, 0, mouseX, 100);



}

function draw() {
  background(204);
  let x1 = map(mouseX, 0, width, 25, 75);
  ellipse(x1, 25, 25, 25);
  //This ellipse is constrained to the 0-100 range
  //after setting withinBounds to true
  let x2 = map(mouseX, 0, width, 0, 100, true);
  ellipse(x2, 75, 25, 25);
  let x3 = map(mouseX, 0, width, 0, 100, true);
  ellipse(x3, 75, 25, 25)
}
