let sliderGroup = [];
let X;
let Y;
let Z;
let centerX;
let centerY;
let centerZ;
let h = 20;

function setup() {
  createCanvas(600, 600, WEBGL);
   for (var i = 0; i < 6; i++) {
    if (i === 2) {
      sliderGroup[i] = createSlider(10, 400, 200);
    } else {
      sliderGroup[i] = createSlider(-400, 400, 0);
    }
    h = map(i, 0, 6, 5, 85);
    sliderGroup[i].position(10, height + h);
    sliderGroup[i].style('width', '80px');
  }

}

function draw() {
  background(200);
 let locX = mouseX - width / 2;
  let locY = mouseY - height / 2;
 pointLight(350, 350, 250, locX, locY, 50);
  noStroke();
  
  normalMaterial();
  sphere(45,95); /// ancient city pillars
  rectMode(LEFT);
  
  cone(53, 80); /// lake
  rectMode(LEFT);
  ambientLight(200);
  ambientMaterial(70, 180, 230);
  
  torus(10,10);
  ambientLight(0);
 
  ambientLight(100); 
  ambientMaterial(255, 102, 94); 
  box(40);

  rectMode(CENTER);
  rect(0, 0, 255, 255);
  fill(200);
  stroke(123);
  
  X = sliderGroup[0].value();
  Y = sliderGroup[1].value();
  Z = sliderGroup[2].value();
  centerX = sliderGroup[3].value();
  centerY = sliderGroup[4].value();
  centerZ = sliderGroup[5].value();
  camera(X, Y, Z, centerX, centerY, centerZ, 0, 1, 0);
  stroke(255);
  fill(255, 102, 94);
  box(85);
  
 ellipsoid(50,40);
 normalMaterial();
  stroke(155);
  fill(100, 100, 55);
  
  box(85, 85, 85); ///mud
  normalMaterial();
  stroke(55);
  fill(55, 55, 100);
  
  sphere(50, 50); ///ground
  rectMode(RIGHT);
  
}
