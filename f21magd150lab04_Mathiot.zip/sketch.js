let djm;
let z;
let y;
function setup() {
  dmv = createCanvas(900, 900);
  dmv.mousePressed(changeGray); 
  z = 10;
  y = 100;
}

function draw() {
  background(y);
  ellipse(width / 3, height / 4, z, z);
}

function mousePressed() {
  z = z + 10;
}
  function changeGray() {
  y = random(0, 255);
       
    
    
let value = 0

  if (keyIsPressed = true){
    fill(255, 241, 11);
  }
  else if (value === 1){
    fill(0, 255, 0);
  }
  else{
    fill(255, 241, 11);
  }
  ellipse(width/3, height/5, 50, 50);
    
  }  
 

let value = 1

  if (keyIsPressed = true){
    fill(255, 241, 11);
  }
  else if (value === 0){
    fill(255, 255, 0);
  }
  else{
    fill(255, 241, 11);
  }
  ellipse(width/3, height/5, 40, 50);





let Mouse = x

  if (keyIsPressed = false){
    fill(255, 241, 11);
  }
  if (value === x){
    fill(255, 255, 255);
  }
  else{
    fill(255, 241, 11);
  }
  ellipse(width/3, height/5, 40, 50);

 













